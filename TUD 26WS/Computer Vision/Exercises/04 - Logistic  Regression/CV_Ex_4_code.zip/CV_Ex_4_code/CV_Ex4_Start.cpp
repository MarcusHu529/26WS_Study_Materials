// TU Dresden, Inf, CV1 Ex4
//-----------------------------------------------------------------------------
#include "opencv2/opencv.hpp"
#include <opencv2/highgui.hpp>
#include "opencv2/imgproc/imgproc.hpp"
#include "opencv2/imgcodecs.hpp"
#include "opencv2/videoio/videoio.hpp"
#include "opencv2/highgui/highgui.hpp"
#include <iostream>
#include <functional>
#include <queue>
#include <vector>

#define KEYCODE_ESC 27
#define KEYCODE_SPACE 32

enum Status_Code{
    STATUS_CONTINUE,
    STATUS_QUIT_APPLICATION
};

#define NEIGHBORHOOD_RADIUS 3
#define NEIGHBORHOOD_SIZE ((NEIGHBORHOOD_RADIUS<<1) + 1)
#define NUM_CHANNELS 3

#define LOG2e 1.44269504089
#define SIGMA 50.0
#define EPSILON 0.001f

//to every pixel s we assign an attribute vector x_s consisting of the NUM_CHANNELS-many color values of the pixels in the NEIGHBORHOOD_SIZExNEIGHBORHOOD_SIZE neighborhood of the pixel.
//we add one additional attribute which we will always set to 1 in order to be able learn a linear function which can have an offset   
#define ATTRIBUTE_VECTOR_SIZE (NEIGHBORHOOD_SIZE * NEIGHBORHOOD_SIZE * NUM_CHANNELS + 1)

Status_Code wait_for_and_process_key_input(){

    while(true){
        int keycode = cv::waitKey(0) & 0xEFFFFF;

        switch (keycode)
        {
        case KEYCODE_ESC:
            return STATUS_QUIT_APPLICATION;
        
        case KEYCODE_SPACE:
            return STATUS_CONTINUE;

        default:
            continue;
        }
    }

}

void help()
{
    std::cout << "Press Space to continue" << std::endl;
    std::cout << "Press Esc to quit the application" << std::endl;
}

int get_flat_pixel_index(int row, int col, int total_num_cols){
    return col + row * total_num_cols;
}

void calculate_linear_function_output(const cv::Mat* X, const cv::Mat& weights, cv::Mat& Y_pred){

    for(int row = 0; row < Y_pred.rows;row++){
        for(int col = 0; col < Y_pred.cols;col++){

            // the variable flat_pixel_index can be used to index the array X in order to get the feature vector of that pixel
            int flat_pixel_index = get_flat_pixel_index(row,col,Y_pred.cols);

            // task 1

            Y_pred.at<float>(row,col) = 0.0f;
        }
    }
}

float calculate_objective_function(const cv::Mat* X, const cv::Mat& weights, const cv::Mat& Y_pred, const cv::Mat& Y_label){


    float obj_function = 0.0;

    for(int row = 0; row < Y_pred.rows;row++){
        for(int col = 0; col < Y_pred.cols;col++){

            // task 2

            obj_function += 0.0f;
        }
    }

    return obj_function;

}

cv::Mat compute_grad(const cv::Mat* X, const cv::Mat& weights, const cv::Mat& Y_pred, const cv::Mat& Y_label){

    cv::Mat grad = cv::Mat::zeros(weights.size(),CV_32F);


    for(int i = 0; i < ATTRIBUTE_VECTOR_SIZE;i++){

        for(int row = 0; row < Y_pred.rows;row++){
            for(int col = 0; col < Y_pred.cols;col++){

                // task 4

                grad.at<float>(0,i) += 0.0f;
            }
        }

    }

    return grad;

}

void get_pixel_pos_with_reflection(int& col, int& row, int total_cols, int total_rows){

    if(col < 0){col = -col - 1;}
    if(col >= total_cols){ col = col - (col - total_cols + 1);}

    if(row < 0){row = -row - 1;}
    if(row >= total_rows){ row = row - (row - total_rows + 1);}

}

cv::Mat* calculate_feature_vectors(cv::Mat& input_image){

    // This function constructs the feature vector x for each pixel s in the image.
    // This feature vector contains the colors values of the neighboring pixels in the NEIGHBORHOOD_SIZE x NEIGHBORHOOD_SIZE neighborhood of the pixel

    int num_pixels = input_image.rows * input_image.cols;

    cv::Mat* feature_vectors = new cv::Mat[num_pixels];

    for(int row = 0; row < input_image.rows;row++){
        for(int col = 0; col < input_image.cols;col++){

            int flat_pixel_index = get_flat_pixel_index(row,col,input_image.cols); 
            feature_vectors[flat_pixel_index] = cv::Mat::ones(1,ATTRIBUTE_VECTOR_SIZE,CV_32F);

            for(int local_row = -NEIGHBORHOOD_RADIUS; local_row <= NEIGHBORHOOD_RADIUS; local_row++){
                for(int local_col = -NEIGHBORHOOD_RADIUS; local_col <= NEIGHBORHOOD_RADIUS; local_col++){
                    int neighbor_row = row + local_row;
                    int neighbor_col = col + local_col;

                    get_pixel_pos_with_reflection(neighbor_col,neighbor_row,input_image.cols,input_image.rows);

                    int flat_neighbor_index = (local_row + NEIGHBORHOOD_RADIUS) * NEIGHBORHOOD_SIZE + (local_col + NEIGHBORHOOD_RADIUS);
                    flat_neighbor_index *= NUM_CHANNELS;

                    feature_vectors[flat_pixel_index].at<float>(0,flat_neighbor_index) = input_image.at<cv::Vec3f>(neighbor_row,neighbor_col)[0];
                    feature_vectors[flat_pixel_index].at<float>(0,flat_neighbor_index + 1) = input_image.at<cv::Vec3f>(neighbor_row,neighbor_col)[1];
                    feature_vectors[flat_pixel_index].at<float>(0,flat_neighbor_index + 2) = input_image.at<cv::Vec3f>(neighbor_row,neighbor_col)[2];
                }   
            }
        }
    }

    return feature_vectors;

} 

void classify_pixels(cv::Mat& image,const cv::Mat& learned_weights){

    //task 7

}

int main( int argc, char** argv )
{
	help();
    
	char* filename = (char*)"../images/flower.png";
    cv::Mat image = imread(filename, cv::IMREAD_COLOR);
    image.convertTo(image,CV_32FC3,1.0f/255.0f);

	cv::namedWindow( "Image",cv::WINDOW_KEEPRATIO);
	cv::imshow( "Image", image );

    filename = (char*)"../images/flower_label.png";
    cv::Mat labels = imread(filename, cv::IMREAD_GRAYSCALE);
    labels.convertTo(labels,CV_32FC1,1.0f/255.0f);

    cv::namedWindow( "Labels",cv::WINDOW_KEEPRATIO);
	cv::imshow( "Labels", labels );

    cv::Mat* X = calculate_feature_vectors(image);

    cv::Mat weights = cv::Mat::zeros(1,ATTRIBUTE_VECTOR_SIZE,CV_32F);

    cv::Mat Y_pred = cv::Mat(image.size(),CV_32F);

    float learning_rate = 0.1;
    int num_epochs = 2000; 

    for(int i = 0; i < num_epochs; i++){

        // task 5
    }

    filename = (char*)"../images/flower_test.png";
    cv::Mat test_image = imread(filename, cv::IMREAD_COLOR);
    test_image.convertTo(test_image,CV_32FC3,1.0f/255.0f);

    classify_pixels(test_image,weights);

    cv::normalize(Y_pred,Y_pred,0,1,cv::NORM_MINMAX);

    cv::imshow("Output",Y_pred);

    if(wait_for_and_process_key_input() == STATUS_QUIT_APPLICATION) return 0;

    delete [] X;

    return 0;

}
