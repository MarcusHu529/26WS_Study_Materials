// TU Dresden, Inf, CV1 Ex2, Jannik Presberger
//-----------------------------------------------------------------------------
#include "opencv2/opencv.hpp"
#include <opencv2/highgui.hpp>
#include "opencv2/imgproc/imgproc.hpp"
#include "opencv2/imgcodecs.hpp"
#include "opencv2/videoio/videoio.hpp"
#include "opencv2/highgui/highgui.hpp"
#include <iostream>
#include <functional>
#include <queue>
#include <vector>

#define KEYCODE_ESC 27
#define KEYCODE_SPACE 32

enum Status_Code{
    STATUS_CONTINUE,
    STATUS_QUIT_APPLICATION
};


float distance_difference_metric(const cv::Point2i& v1, const cv::Point2i& v2);

template<typename Color_Datatype> float color_difference_metric(Color_Datatype c1, Color_Datatype c2);

float get_distance_metric_weight(float dist_metric);

float get_color_metric_weight(float color_metric);

void get_neighborhood(cv::Point2i v, cv::Mat* image, std::vector<cv::Point2i>& neighbors, float (*ds)(const cv::Point2i& v1, const cv::Point2i& v2), float distance_threshold);

template<typename Color_Datatype> void calculate_bilateral_filtering(   cv::Mat* input_img, cv::Mat* output_img,
                                                                        float (*ds)(const cv::Point2i& v1, const cv::Point2i& v2), 
                                                                        float (*dc)(Color_Datatype c1, Color_Datatype c2), 
                                                                        float (*ws)(float dist_metric), 
                                                                        float (*wc)(float color_metric), 
                                                                        void (*N)(cv::Point2i v, cv::Mat* image, std::vector<cv::Point2i>& neighbors, float (*ds)(const cv::Point2i& v1, const cv::Point2i& v2), float distance_threshold));

void calculate_harris_corner_detection( cv::Mat& img, 
                                        float (*ds)(const cv::Point2i& v1, const cv::Point2i& v2), 
                                        void (*N)(cv::Point2i v, cv::Mat* image, std::vector<cv::Point2i>& neighbors, float (*ds)(const cv::Point2i& v1, const cv::Point2i& v2), float distance_threshold));

Status_Code wait_for_and_process_key_input(){

    while(true){
        int keycode = cv::waitKey(0) & 0xEFFFFF;

        switch (keycode)
        {
        case KEYCODE_ESC:
            return STATUS_QUIT_APPLICATION;
        
        case KEYCODE_SPACE:
            return STATUS_CONTINUE;

        default:
            continue;
        }
    }

}

void help()
{
	std::cout << "\nTU Dresden, Inf, CV1 Ex3" << std::endl;
    std::cout << "Press Space to continue" << std::endl;
    std::cout << "Press Esc to quit the application" << std::endl;
}



/*
// This code together with the block in the main function adds 3 trackbars/sliders to the main window which adjust 3 global variables (sigma_c_global,sigma_s_global and neighborhood_distance_global).
// You can use this to make certain parameters of your bilateral filter implementation variable, if you so choose.

typedef struct Trackbar_Input_Struct{
    cv::Mat* input_img;
    cv::Mat* output_img;
    double* adjustable_var;
}Trackbar_Input_Struct;

const int sigma_c_slider_max = 150;
int sigma_c_slider = 50;
double sigma_c_global = sigma_c_slider;

const int sigma_s_slider_max = 15;
int sigma_s_slider = 5;
double sigma_s_global = sigma_s_slider;

const int neighborhood_distance_slider_max = 15;
int neighborhood_distance_slider = 5;
double neighborhood_distance_global = neighborhood_distance_slider;

int microsec_trackbar_cooldown = 33000;
std::chrono::steady_clock::time_point last_trackbar_call_timestamp = std::chrono::steady_clock::now();

static void on_trackbar(int slider, void* user_data)
{
    std::chrono::steady_clock::time_point current_timestamp = std::chrono::steady_clock::now();

    if(std::chrono::duration_cast<std::chrono::microseconds>(current_timestamp - last_trackbar_call_timestamp).count() > microsec_trackbar_cooldown){
        last_trackbar_call_timestamp = current_timestamp;

        Trackbar_Input_Struct* input = (Trackbar_Input_Struct*)user_data;

        *(input->adjustable_var) = (double) slider;
        calculate_bilateral_filtering<uint8_t>(input->input_img,input->output_img,distance_difference_metric,color_difference_metric,get_distance_metric_weight,get_color_metric_weight,get_neighborhood);

        //std::cout << "sigma_c: " << sigma_c_global << std::endl;
        //std::cout << "sigma_s: " << sigma_s_global << std::endl;
        //std::cout << "neighborhood_distance: " << neighborhood_distance_global << std::endl;
        //std::cout << std::endl;

        cv::imshow( "Bilateral Fruits", *(input->output_img));
    }
}
*/


float distance_difference_metric(const cv::Point2i& v1, const cv::Point2i& v2){

    //task 1

    return 0.0f;
} 

template<typename Color_Datatype> float color_difference_metric(Color_Datatype c1, Color_Datatype c2){

    //task 1

    return 0.0f;
}

float get_distance_metric_weight(float dist_metric){

    //task 1

    return 1.0;
}

float get_color_metric_weight(float color_metric){

    //task 1

    return 1.0f;
}


void get_neighborhood(cv::Point2i v, cv::Mat* image, std::vector<cv::Point2i>& neighbors, float (*ds)(const cv::Point2i& v1, const cv::Point2i& v2), float distance_threshold){

    //task 1

    neighbors.clear();

    return;
}

template<typename Color_Datatype> void calculate_bilateral_filtering(   cv::Mat* input_img, cv::Mat* output_img,
                                                                        float (*ds)(const cv::Point2i& v1, const cv::Point2i& v2), 
                                                                        float (*dc)(Color_Datatype c1, Color_Datatype c2), 
                                                                        float (*ws)(float dist_metric), 
                                                                        float (*wc)(float color_metric), 
                                                                        void (*N)(cv::Point2i v, cv::Mat* image, std::vector<cv::Point2i>& neighbors, float (*ds)(const cv::Point2i& v1, const cv::Point2i& v2), float distance_threshold)){


    for(int row = 0 ; row < input_img->rows; row++){
        for(int col = 0 ; col < input_img->cols; col++){

            //task 1

            output_img->at<Color_Datatype>(row,col) = input_img->at<Color_Datatype>(row,col);
        }
    }

}


void calculate_harris_corner_detection( cv::Mat& img, 
                                        float (*ds)(const cv::Point2i& v1, const cv::Point2i& v2), 
                                        void (*N)(cv::Point2i v, cv::Mat* image, std::vector<cv::Point2i>& neighbors, float (*ds)(const cv::Point2i& v1, const cv::Point2i& v2), float distance_threshold)){


    //task 8

}



int main( int argc, char** argv )
{
	help();
    
	char* filename = (char*)"../images/fruits_noisy.jpg";
    cv::Mat image = imread(filename, cv::IMREAD_GRAYSCALE);

    cv::Mat output_img = cv::Mat::zeros(image.rows,image.cols,CV_8U);


	cv::namedWindow( "Fruits!",cv::WINDOW_KEEPRATIO);
	cv::imshow( "Fruits!", image );

    cv::namedWindow( "Bilateral Fruits",cv::WINDOW_AUTOSIZE);

    calculate_bilateral_filtering<uint8_t>(&image,&output_img,distance_difference_metric,color_difference_metric,get_distance_metric_weight,get_color_metric_weight,get_neighborhood);

    cv::imshow( "Bilateral Fruits", output_img);


    /*
    char sigma_c_trackbar_name[50] = "sigma_c";
    Trackbar_Input_Struct trackbar_sigma_c_input{&image,&output_img,&sigma_c_global};

    cv::createTrackbar( sigma_c_trackbar_name, "Bilateral Fruits", nullptr, sigma_c_slider_max, on_trackbar,&trackbar_sigma_c_input);
    cv::setTrackbarPos(sigma_c_trackbar_name,"Bilateral Fruits",sigma_c_slider);
    cv::setTrackbarMin(sigma_c_trackbar_name,"Bilateral Fruits",1);


    char sigma_s_trackbar_name[50] = "sigma_s";
    Trackbar_Input_Struct trackbar_sigma_s_input{&image,&output_img,&sigma_s_global};

    cv::createTrackbar( sigma_s_trackbar_name, "Bilateral Fruits", nullptr, sigma_s_slider_max, on_trackbar,&trackbar_sigma_s_input);
    cv::setTrackbarPos(sigma_s_trackbar_name,"Bilateral Fruits",sigma_s_slider);
    cv::setTrackbarMin(sigma_s_trackbar_name,"Bilateral Fruits",1);

    char neighborhood_distance_trackbar_name[50] = "neighborhood_distance";
    Trackbar_Input_Struct trackbar_neighborhood_distance_input{&image,&output_img,&neighborhood_distance_global};

    cv::createTrackbar( neighborhood_distance_trackbar_name, "Bilateral Fruits", nullptr, neighborhood_distance_slider_max, on_trackbar,&trackbar_neighborhood_distance_input);
    cv::setTrackbarPos(neighborhood_distance_trackbar_name,"Bilateral Fruits",neighborhood_distance_slider);
    cv::setTrackbarMin(neighborhood_distance_trackbar_name,"Bilateral Fruits",1);
    on_trackbar( neighborhood_distance_slider, &trackbar_neighborhood_distance_input);
    */

    if(wait_for_and_process_key_input() == STATUS_QUIT_APPLICATION) return 0;

    return 0;

}
